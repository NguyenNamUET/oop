public class Main {
    public static void main(String[] args) {
        Actions test = new Actions();
        test.genData();
        test.display();
    }
}
